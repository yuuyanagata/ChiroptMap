%oldchk=../01_molecule1_td_s1_opt_iop9404.chk
%chk=04_molecule1_scf_allmo_wfx.chk
%mem=76800MB
#p B3LYP/6-311G(2d,p) EmpiricalDispersion=GD3BJ Geom=AllCheck Guess=Read Output=WFX IOp(99/18=-1)

04_molecule1_scf_allmo_wfx.wfx

