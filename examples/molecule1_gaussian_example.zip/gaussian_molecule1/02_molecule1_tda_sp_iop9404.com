%oldchk=01_molecule1_td_s1_opt_iop9404.chk
%chk=02_molecule1_tda_sp_iop9404.chk
%mem=76800MB
#p TDA=(NStates=6) B3LYP/6-311G(2d,p) EmpiricalDispersion=GD3BJ Geom=AllCheck Guess=Read IOp(9/40=4)

