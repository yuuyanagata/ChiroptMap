# Molecule 1 Gaussian example

This archive contains the production Gaussian input/output files and the two
state-1 total transition-moment-density cubes used for the ChiroptMap
validation example.

## Calculation

- Program: Gaussian 16 Revision C.02
- Method: B3LYP-D3(BJ)/6-311G(2d,p)
- Excited-state model: TDA, six roots
- Printed-amplitude setting: `IOp(9/40=4)`
- Map state: S1
- ChiroptMap density mode: `validation`
- Grid spacing: 0.366312 bohr in x, y, and z

## Files

- `02_molecule1_tda_sp_iop9404.com`: production TDA single-point input.
- `02_molecule1_tda_sp_iop9404.out`: normally terminated Gaussian output.
- `04_molecule1_scf_allmo_wfx.com`: production canonical all-MO WFX input.
- `04_molecule1_scf_allmo_wfx.out`: normally terminated Gaussian output for
  the WFX-generation job.
- `molecule1_gaussian_tda_S1_full_EDTM_total.cube`: total electric-dipole
  transition-moment-density map.
- `molecule1_gaussian_tda_S1_full_MDTM_total.cube`: total magnetic-dipole
  transition-moment-density map.
- `SHA256SUMS.txt`: checksums for the files in this archive.

The production inputs use `Geom=AllCheck` and `Guess=Read` with the preceding
optimization checkpoint. They are preserved here as provenance rather than as
standalone geometry inputs. Direct map regeneration additionally requires
`04_molecule1_scf_allmo_wfx.wfx`, which is not included in this compact public
example. The cube filenames and first-line labels have been normalized from
the archived `TEDM`/`TMDM` word order to ChiroptMap v0.2.0 terminology
(`EDTM`/`MDTM`); all numerical grid data are unchanged.

ChiroptMap: https://github.com/yuuyanagata/ChiroptMap

