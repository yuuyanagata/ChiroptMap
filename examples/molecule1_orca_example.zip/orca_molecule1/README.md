# Molecule 1 ORCA example

This archive contains the production ORCA input/output files and the two
state-1 total transition-moment-density cubes used for the ChiroptMap
cross-engine validation example.

## Calculation

- Program: ORCA 6.1.1
- Method: B3LYP-D3(BJ)/6-311G(2d,p), TightSCF
- Excited-state model: closed-shell TDA, six roots
- ORCA print threshold: `TPrint 1e-8`
- ChiroptMap coefficient cutoff: `1e-4`
- Map state: S1

## Files

- `molecule1_orca_tda.inp`: production ORCA input.
- `molecule1_orca_tda.xyz`: Cartesian coordinates read by the input.
- `molecule1_orca_tda.out`: normally terminated ORCA output.
- `molecule1_orca_tda_S1_full_EDTM_total.cube`: total electric-dipole
  transition-moment-density map.
- `molecule1_orca_tda_S1_full_MDTM_total.cube`: total magnetic-dipole
  transition-moment-density map.
- `SHA256SUMS.txt`: checksums for the files in this archive.

Direct map regeneration additionally requires the ORCA JSON and occupied-MO
WFX exports. Those large intermediates are not included in this compact public
example. The cube filenames and first-line labels have been normalized from
the archived `TEDM`/`TMDM` word order to ChiroptMap v0.2.0 terminology
(`EDTM`/`MDTM`); all numerical grid data are unchanged.

ChiroptMap: https://github.com/yuuyanagata/ChiroptMap

